VERSIÓN 2 - LIGA DE FÚTBOL RÁPIDO POTREROS

Incluye:
- Logo extraído de la imagen proporcionada.
- Tabla actual de 12 equipos.
- Primeros 8 equipos destacados.
- Secciones de Resultados y Jornadas preparadas para capturar datos.
- Noticias y diseño adaptable a celular.

Los resultados individuales y el calendario no se inventaron porque no aparecen en la imagen proporcionada.
Abre index.html para visualizar el sitio.
